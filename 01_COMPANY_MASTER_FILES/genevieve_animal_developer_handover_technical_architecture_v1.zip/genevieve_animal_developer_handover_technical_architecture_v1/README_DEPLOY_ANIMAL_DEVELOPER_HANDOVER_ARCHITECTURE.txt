GENEVIEVE ANIMAL DEVELOPER HANDOVER, TECHNICAL ARCHITECTURE & PRODUCTION BUILD PACK V1

Prototype only. Production requires professional software engineering, cloud architecture, privacy, cybersecurity, payment compliance, AI governance, animal-welfare, legal, insurance and testing review.
