# GENEVIEVE™ App PARKPOST™

Static deployable dispenser and bin telemetry simulator.

Includes cartridge magazine, dispenser mechanism visual, quantity controls, dispense/take/reset, system status, telemetry metrics, system log, Australian patent badge, and GENEVIEVE™ App / PARKPOST™ trademarks.

Vercel: Other, no build command, no install command, output blank or `.`.

No npm, no package.json, no node_modules, no dist.
